# 🎂 Birthday Wish App

A beautiful Python + HTML birthday web app with circular photo orbit animation.

---

## 📁 Folder Structure

```
birthday_app/
├── app.py                  ← Flask backend (customize here!)
├── requirements.txt
├── templates/
│   └── index.html          ← Frontend UI
└── static/
    └── photos/             ← ⭐ DROP HER PHOTOS HERE ⭐
        ├── 01.jpg
        ├── 02.jpg
        └── ...
```

---

## 🚀 How to Run

1. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

2. **Add her photos**
   - Drop any `.jpg / .jpeg / .png / .webp` files into `static/photos/`
   - Name them `01.jpg`, `02.jpg`, … (sorted alphabetically in orbit)

3. **Customize** — open `app.py` and edit the top section:
   ```python
   BIRTHDAY_PERSON  = "Yashu"           # Her name
   BIRTHDAY_MESSAGE = "THANK YOU FOR GIVING GOOD MEMORIES..."
   SENDER_NAME      = "Forever Yours ❤️"
   ACCENT_COLOR     = "#FF6B9D"         # Hex color
   ```

4. **Run**
   ```bash
   python app.py
   ```
   Then open → **http://localhost:5000**

---

## ✨ Features

| Feature | Description |
|---|---|
| 🌀 Circular Orbit | Photos rotate on two rings around a glowing heart center |
| 💖 Lightbox | Click any photo to view it full-size |
| 🎊 Confetti | Auto-falling colorful confetti |
| ✨ Particles | Floating glowing particles |
| 💕 Heart Trail | Hearts follow the mouse cursor |
| 🎂 Cake Icons | Animated row of celebration icons |
| 📱 Responsive | Works on mobile and desktop |

---

## 🎨 Quick Alterations

| What to change | Where |
|---|---|
| Her name | `app.py` → `BIRTHDAY_PERSON` |
| The message | `app.py` → `BIRTHDAY_MESSAGE` |
| Sender name | `app.py` → `SENDER_NAME` |
| Theme color | `app.py` → `ACCENT_COLOR` |
| Number of cakes | `index.html` → `NUM_CAKES` |
| Orbit speed | `index.html` → CSS `18s` / `24s` values |
| Orbit size | `index.html` → `ORBIT_RADIUS` array |
